const $ = s => document.querySelector(s);
const el = (t, a = {}, ...k) => { const e = document.createElement(t); Object.assign(e, a); e.append(...k); return e; };
const api = async (p, m = 'GET', b) => {
  const r = await fetch('/api/' + p, { method: m, headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Erreur');
  return j;
};
const run = f => async () => { try { await f(); } catch (e) { alert(e.message); } };

const fmt = v => v == null ? '' : typeof v === 'boolean' ? (v ? 'oui' : 'non') : (typeof v === 'string' && /^\d{4}-\d\d-\d\dT/.test(v)) ? new Date(v).toLocaleString('fr-FR') : v;
const table = (rows, empty) => !rows.length ? el('p', {}, empty)
  : el('table', {}, el('thead', {}, el('tr', {}, ...Object.keys(rows[0]).map(k => el('th', {}, k.replace(/_/g, ' '))))),
      el('tbody', {}, ...rows.map(r => el('tr', {}, ...Object.values(r).map(v => el('td', {}, String(fmt(v))))))));

async function dash() {
  $('#auth').hidden = true; $('#dash').hidden = false;
  $('#today').textContent = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const s = await api('admin/stats');
  const kpi = (l, v, n) => el('div', { className: 'kpi' }, el('small', {}, l), el('b', {}, String(v)), el('span', {}, n));
  $('#kpis').replaceChildren(
    kpi('Utilisateurs', s.users, 'comptes inscrits'),
    kpi('Commandes', s.orders, 'au total'),
    kpi('Encaissé', Number(s.revenue).toLocaleString('fr-FR'), 'francs (abonnements)'));
  const pend = await api('admin/merchants/pending');
  $('#pending').replaceChildren(...(pend.length ? pend : [null]).map(m => m
    ? el('div', { className: 'row' }, m.shop_name + ' - ' + m.name + ' (' + m.email + ') ',
        el('button', { onclick: run(async () => { await api('admin/merchants/' + m.id + '/validate', 'POST', {}); await dash(); }) }, 'Valider'))
    : el('p', {}, 'Aucun commerçant en attente.')));
  const nb = $('#bValid'); nb.textContent = pend.length; nb.hidden = !pend.length;
  const nt = await api('notifications');
  $('#adminNotifs').replaceChildren(...(nt.items.length ? nt.items.slice(0, 10) : [null]).map(n => n ? el('div', { className: 'row' }, (n.read ? '' : '● ') + n.title + (n.body ? ' — ' + n.body : '')) : el('p', {}, 'Aucune notification.')));
  if (nt.unread) await api('notifications/read', 'POST', {});
  const sr = await api('admin/star-requests');
  $('#starReq').replaceChildren(...(sr.length ? sr : [null]).map(m => m
    ? el('div', { className: 'row' }, m.shop_name + ' (' + m.email + ') · ' + (m.rating ? m.rating + '/5, ' + m.reviews + ' avis' : 'aucun avis') + ' ',
        el('button', { onclick: run(async () => { await api('admin/merchants/' + m.id + '/stars', 'POST', { decision: 'approve' }); await dash(); }) }, 'Confirmer'), ' ',
        el('button', { onclick: run(async () => { await api('admin/merchants/' + m.id + '/stars', 'POST', { decision: 'reject' }); await dash(); }) }, 'Refuser'))
    : el('p', {}, 'Aucune demande en attente.')));
  const arts = await api('admin/articles');
  $('#arts').replaceChildren(...arts.map(a => el('div', { className: 'row' },
    a.name + ' - ' + a.shop_name + ' - ' + a.price + ' francs' + (a.moderation === 'removed' ? ' [RETIRÉ]' : '') + ' ',
    ...(a.moderation === 'ok' ? [el('button', { onclick: run(async () => { const reason = prompt('Motif du retrait (produit illégal, etc.) :'); if (reason) { await api('admin/articles/' + a.id + '/remove', 'POST', { reason }); await dash(); } }) }, 'Retirer')] : []))));
  const promos = await api('admin/promos');
  $('#promos').replaceChildren(
    el('div', { className: 'row' },
      el('input', { id: 'pcCode', placeholder: 'CODE (ex : BIENVENUE)', maxLength: 30 }),
      el('input', { id: 'pcStd', type: 'number', placeholder: 'Standard (1500)', value: 1500 }),
      el('input', { id: 'pcPre', type: 'number', placeholder: 'Premium (3000)', value: 3000 }),
      el('input', { id: 'pcMax', type: 'number', placeholder: 'Utilisations max (facultatif)' }),
      el('button', { onclick: run(async () => {
        await api('admin/promos', 'POST', { code: $('#pcCode').value, standardPrice: +$('#pcStd').value, premiumPrice: +$('#pcPre').value, maxUses: $('#pcMax').value ? +$('#pcMax').value : null });
        await dash(); }) }, 'Créer le code')),
    ...promos.map(p => el('div', { className: 'row' },
      p.code + ' · Standard ' + p.standard_price + ' / Premium ' + p.premium_price + ' francs · ' + p.uses + (p.max_uses ? ' / ' + p.max_uses : '') + ' utilisation(s) · ' + (p.active ? 'actif' : 'désactivé') + ' ',
      el('button', { onclick: run(async () => { await api('admin/promos/' + p.id + '/toggle', 'POST', {}); await dash(); }) }, p.active ? 'Désactiver' : 'Activer'))));
  const users = await api('admin/users');
  $('#users').replaceChildren(...users.map(u => el('div', { className: 'row' },
    u.name + ' - ' + u.role + ' - ' + u.status + ' ',
    ...(u.role !== 'admin' && u.status === 'active'
      ? [el('button', { onclick: run(async () => { if (confirm('Suspendre ' + u.name + ' ?')) { await api('admin/users/' + u.id + '/suspend', 'POST', {}); await dash(); } }) }, 'Suspendre')] : []))));
  const ov = await api('admin/overview');
  $('#dbShops').replaceChildren(table(ov.shops, 'Aucune entreprise inscrite.'));
  $('#dbArts').replaceChildren(table(ov.articles, 'Aucun article.'));
  $('#dbClients').replaceChildren(table(ov.clients, 'Aucun client inscrit.'));
  $('#dbOrders').replaceChildren(table(ov.orders, 'Aucune commande.'));
  $('#dbPay').replaceChildren(table(ov.payments, 'Aucun paiement.'));
  $('#dbPlans').replaceChildren(table(ov.plans, 'Aucun abonnement.'));
  $('#dbRev').replaceChildren(table(ov.reviews, 'Aucun avis.'));
  $('#dbMsg').replaceChildren(table(ov.messages, 'Aucun message.'));
  $('#dbLog').replaceChildren(table(ov.journal, 'Aucune opération.'));
}
$('#go').onclick = run(async () => {
  const r = await api('admin/login', 'POST', { email: $('#email').value, password: $('#password').value });
  $('#login').hidden = true; $('#step2').hidden = false;
  $('#setup').hidden = r.step !== 'setup';
  if (r.step === 'setup') $('#secret').textContent = r.secret;
});
$('#verify').onclick = run(async () => { await api('admin/2fa', 'POST', { code: $('#code').value }); $('#code').value = ''; await dash(); });
document.querySelectorAll('#nav button[data-v]').forEach(b => b.onclick = () => {
  document.querySelectorAll('#nav button[data-v]').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + b.dataset.v));
});
$('#logoutIcon').onclick = () => $('#logout').click();
$('#logout').onclick = run(async () => { await api('logout', 'POST', {}); location.reload(); });
api('me').then(m => { if (m.role === 'admin') dash(); }).catch(() => {});
